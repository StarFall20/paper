"""Prepare the plain-language public survey after the 2026-10-24 revision.

No invitation token, age screening, contact/identity field, comprehension quiz,
or pilot burden questions are present. Raw menu codes remain unchanged.
"""
from pathlib import Path
import csv
import hashlib
import html
import json
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'survey/public_dh36'

def render_card(path, attrs, vals):
    """A legible 3-column comparison for Wenjuanxing's filtered title editor."""
    font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Unicode.ttf',42)
    small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Unicode.ttf',40)
    widths=[228,426,426]
    def wrap(text,width,f):
        lines=[];line=''
        for ch in text:
            if f.getlength(line+ch)>width and line:lines.append(line);line=''
            line+=ch
        return lines+[line]
    rows=[['比较项目','服务 A','服务 B']]+[[a,vals[0][i],vals[1][i]] for i,a in enumerate(attrs)]
    wrapped=[[wrap(c,widths[j]-42,font if ri==0 else small) for j,c in enumerate(row)] for ri,row in enumerate(rows)]
    heights=[max(106, max(map(len,row))*58+44) for row in wrapped]
    im=Image.new('RGB',(1080,sum(heights)+2),'white');d=ImageDraw.Draw(im)
    y=1
    for ri,(row,h) in enumerate(zip(wrapped,heights)):
        x=0
        for j,lines in enumerate(row):
            d.rectangle((x,y,x+widths[j],y+h),fill='#eef2f5' if ri==0 else 'white',outline='#afb7c0',width=2)
            yy=y+(h-len(lines)*58)/2
            for line in lines:
                d.text((x+21,yy),line,font=font if ri==0 else small,fill='#15222d'); yy+=58
            x+=widths[j]
        y+=h
    im.save(path)


def build():
    prior=json.loads((ROOT/'survey/fielding_v35/instrument.json').read_text())
    spec={
        'instrument_id':'digital_health_public_20261024_dh36',
        'title':'健康管理服务选择问卷',
        'introduction':[
            '本问卷了解大家如何选择健康管理类手机服务，预计需要5至7分钟。问卷不记名，不询问身份或联系方式，结果仅作整体研究分析。参与自愿，您可以随时退出。',
            '请想象您正考虑订阅一项记录运动、作息和日常健康信息的手机服务。每题比较两个服务，请选更愿意使用的一项；两个都不愿意使用时，选择“都不选择”。',
            '费用按使用一个月计算，请考虑自己的实际预算。所有服务均为假设情景，填写问卷不会收费。题目未列出的功能和条件相同。',
            '“记录保存”指服务商内部如何保存和处理记录；“对外共享”指是否把记录提供给其他机构。研究结果支持某项服务，并不保证每个人都有相同效果。'
        ],
        'attribute_order':['记录保存','咨询支持','提醒方式','效果研究','对外共享','每月费用'],
        'labels':{
            'D0':'只保存在手机内','D1':'手机保存，并有加密备份','D2':'在加密云端保存和处理',
            'S1':'可向护士在线咨询','S2':'可向健康专业团队在线咨询',
            'I0':'按固定时间提醒','I1':'根据使用情况调整提醒时间',
            'E0':'还没有公开的效果研究','E1':'1项小规模研究支持其效果','E2':'多项独立研究支持其效果',
            'G0':'不向外部机构共享','G1':'去掉身份信息后提供给科研机构','G2':'是否共享、共享给谁由您决定'
        },
        'profiles':prior['profiles'],'tasks':prior['tasks'],
        'choices':['服务 A','服务 B','都不选择'],
        'common_questions':[
            {'number':9,'id':'app_use','prompt':'过去一年，您使用运动记录、睡眠记录或健康管理类手机应用的频率是？','options':['从未使用','偶尔使用，每月不到1次','每月使用，但不是每周都用','每周至少使用1次','不想回答']},
            {'number':10,'id':'paid_service','prompt':'过去一年，您是否为这类应用支付过会员费或订阅费？','options':['付过，现在仍在付费使用','付过，现在已不再付费使用','没有付过','记不清','不想回答']},
            {'number':11,'id':'priority','prompt':'选择这类服务时，您通常最在意哪一项？','options':['每月费用','记录如何保存','能否咨询专业人员','提醒方式','有没有研究支持其效果','记录是否对外共享','没有固定侧重','不想回答']}
        ],
        'end_message':'感谢您的参与！',
        'assignment':{'respondent_facing_token':False,'versions':['V1','V2'],'self_selection_allowed':False,
                      'wjx_scenario_random_requires_enterprise':True,
                      'public_entry_randomizer':'not implemented; researcher-side random allocation is required'},
        'platform_state_file':'platform_state.json'
    }
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'cards').mkdir(exist_ok=True)
    (OUT/'instrument.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
    (OUT/'共同问卷说明.txt').write_text('\n\n'.join([spec['title']]+spec['introduction'])+'\n')
    rows=[]
    for version in ('V1','V2'):
        blocks=[spec['title']]
        for n,t in enumerate(spec['tasks'],1):
            vals=[]
            for ai,a in enumerate(('A','B')):
                raw=spec['profiles'][version][a]
                v=[spec['labels'][c] for c in raw]+[spec['labels'][t['sharing'][ai]],str(t['prices'][ai])+'元']
                vals.append(v)
                rows.append({'version':version,'task_id':t['task_id'],'question_number':n,'alternative':a,
                             'raw_profile':':'.join(raw),'sharing':t['sharing'][ai],'price':t['prices'][ai],
                             'candidate_1':sum(int(c[1:]) for c in raw[:2]),'candidate_2':sum(int(c[1:]) for c in raw[2:])})
            stem=f'{n}. 如果只能选择一项，您会选哪个？'
            for ai,a in enumerate(('A','B')):
                stem+=' 服务'+a+'：'+'；'.join(x+'：'+y for x,y in zip(spec['attribute_order'],vals[ai]))+'。'
            blocks.append(stem+' [单选题]\n'+'\n'.join(chr(65+i)+'. '+s for i,s in enumerate(spec['choices'])))
            card='<p><strong>第'+str(n)+'题</strong> 如果只能选择一项，您会选哪个？</p>'
            card+='<table style="width:100%;border-collapse:collapse;font-size:15px;line-height:1.6;table-layout:fixed"><colgroup><col style="width:24%"><col style="width:38%"><col style="width:38%"></colgroup>'
            for ri,row in enumerate([['比较项目','服务 A','服务 B']]+[[a,vals[0][i],vals[1][i]] for i,a in enumerate(spec['attribute_order'])]):
                card+='<tr>'+''.join('<td style="border:1px solid #d9d9d9;padding:8px;'+('background:#eef2f5;font-weight:bold;' if ri==0 else '')+'">'+html.escape(c)+'</td>' for c in row)+'</tr>'
            card+='</table><p style="font-size:13px">“都不选择”表示本题不订阅新服务，费用为0元，继续使用原有方式。</p>'
            (OUT/'cards'/f'{version}_{t["task_id"]}.html').write_text(card)
            render_card(OUT/'cards'/f'{version}_{t["task_id"]}.png',spec['attribute_order'],vals)
        for q in spec['common_questions']:
            blocks.append(str(q['number'])+'. '+q['prompt']+' [单选题]\n'+'\n'.join(chr(65+i)+'. '+s for i,s in enumerate(q['options'])))
        (OUT/f'问卷星导入_{version}.txt').write_text('\n\n'.join(blocks)+'\n')
    with (OUT/'menu_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
    for task in prior['tasks']:
        for a in ('A','B'):
            pair=[next(r for r in rows if r['version']==v and r['task_id']==task['task_id'] and r['alternative']==a) for v in ('V1','V2')]
            assert all(pair[0][k]==pair[1][k] for k in ('sharing','price','candidate_1','candidate_2'))
    for q in spec['common_questions']:
        assert not any(x in q['prompt'] for x in ('邀请码','身份证','手机号','姓名','年龄'))
    (OUT/'revision_record.md').write_text('''# DH36正式问卷修改记录

日期 2026年10月24日

按用户要求删除邀请码、年龄确认和单独的同意勾选题，移除理解测验、难度及现实感预测试题。
保留八道服务选择题，增加三道简短的应用使用与选择侧重题，共十一题。所有题目均不询问身份、联系方式、疾病或病历。
问卷介绍缩为四段，明确自愿、退出、假设情景和无真实收费。未编造机构、伦理编号或联系人。
六项属性改用日常用语，卡片采用左右对照表格。两版原始代码、共享方式和价格保持相同的候选保持配对。
措辞已改变，旧预测试文件继续归档，不能将其记为已验证的新测量工具。正式回收需记录实际版本与招募渠道。
当前账号的情景随机题经界面核实需企业版才能发布；在分配方式落实前，不宣称已实现平台自动随机。
''')
    print('DH36 public survey prepared: 11 questions per version, 8 choices, 0 identifying fields')


if __name__=='__main__':build()
