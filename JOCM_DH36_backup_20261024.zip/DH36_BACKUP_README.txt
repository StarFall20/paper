DH36 2026-10-24 backup

The current public survey has 11 questions per version, no invitation/age/identity/contact fields, and no pilot-feedback questions. Wenjuanxing drafts: V1 390522225; V2 390535906. Both contain 8 uploaded comparison cards and 11 pages; mobile previews were inspected. They are not published and no participant response was submitted. Automatic respondent allocation is not implemented.

The code snapshot is the committed local source tree at 5fd6b8f. It excludes the current unresolved merge working tree. No remote file is overwritten. Private allocation tables and participant data are excluded. The public packet includes the current platform state separately from the source snapshot.

GitHub backup branch: backup/dh36-20261024, based on remote main. The archive is an additive backup, not a claim that local and remote histories have been reconciled.
